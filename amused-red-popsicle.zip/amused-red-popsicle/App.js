com.coco.assistant/
├── core/
│   ├── network/          # Retrofit / Ktor client, backend proxies
│   ├── datastore/        # User preferences, flags
│   ├── database/         # Room DB (Conversation history, explicit memories)
│   └── util/             # Coroutine dispatchers, extensions
├── domain/
│   ├── model/            # CocoState, IntentRoute, VoiceState, ActionResult
│   ├── orchestrator/     # CocoOrchestrator, IntentClassifier
│   └── skills/           # Base Skill interface & Registry
├── data/
│   ├── voice/            # Android SpeechRecognizer & TextToSpeech wrappers
│   ├── skills/           # Concrete implementations (Apps, Alarms, Maps, etc.)
│   └── memory/           # MemoryRepository implementation
└── ui/
    ├── theme/            # Material 3 dynamic color & typography
    ├── components/       # Glowing AI Orb, Audio waveform canvas
    ├── home/             # Main voice screen & bottom sheet interaction
    └── settings/         # Privacy controls, memory management
    // domain/model/VoiceState.kt
package com.coco.assistant.domain.model

sealed interface VoiceState {
    object Idle : VoiceState
    object Listening : VoiceState
    object Understanding : VoiceState
    object Thinking : VoiceState
    data class Speaking(val message: String) : VoiceState
    data class Error(val message: String, val canRetry: Boolean = true) : VoiceState
}

// domain/model/ActionResult.kt
package com.coco.assistant.domain.model

sealed class ActionResult {
    data class Success(
        val spokenFeedback: String,
        val displayFeedback: String? = null,
        val executionSteps: List<String> = emptyList()
    ) : ActionResult()

    data class Failure(
        val spokenFeedback: String,
        val technicalReason: String? = null
    ) : ActionResult()

    data class RequiresConfirmation(
        val prompt: String,
        val onConfirmPayload: IntentPayload
    ) : ActionResult()

    data class NeedsClarification(
        val clarificationQuestion: String
    ) : ActionResult()
}

data class IntentPayload(
    val actionType: String,
    val parameters: Map<String, Any> = emptyMap()
)
// domain/skills/CocoSkill.kt
package com.coco.assistant.domain.skills

import com.coco.assistant.domain.model.ActionResult
import com.coco.assistant.domain.model.IntentPayload

interface CocoSkill {
    val id: String
    val displayName: String
    val requiredPermissions: List<String> get() = emptyList()

    /**
     * Determines whether this skill can handle the given intent payload.
     */
    fun canHandle(payload: IntentPayload): Boolean

    /**
     * Executes the skill deterministically via Android official APIs.
     */
    suspend fun execute(payload: IntentPayload): ActionResult
}
// domain/skills/SkillRegistry.kt
package com.coco.assistant.domain.skills

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SkillRegistry @Inject constructor(
    private val skills: Set<@JvmSuppressWildcards CocoSkill>
) {
    fun findSkill(payload: IntentPayload): CocoSkill? {
        return skills.firstOrNull { it.canHandle(payload) }
    }
}
// domain/orchestrator/CocoOrchestrator.kt
package com.coco.assistant.domain.orchestrator

import com.coco.assistant.domain.model.ActionResult
import com.coco.assistant.domain.model.IntentPayload
import com.coco.assistant.domain.skills.SkillRegistry
import javax.inject.Inject
import javax.inject.Singleton

enum class ExecutionRoute {
    DIRECT_ANDROID_ACTION,
    AI_CONVERSATION,
    WEB_SEARCH,
    MEMORY_OPERATION,
    MULTI_STEP_TASK,
    UNSUPPORTED
}

data class RouteResolution(
    val route: ExecutionRoute,
    val payload: IntentPayload,
    val requiresConfirmation: Boolean = false,
    val confirmationPrompt: String? = null
)

interface IntentClassifier {
    suspend fun classify(userInput: String): RouteResolution
}

interface AiBrainService {
    suspend fun askAssistant(prompt: String, conversationId: String): String
}

@Singleton
class CocoOrchestrator @Inject constructor(
    private val classifier: IntentClassifier,
    private val skillRegistry: SkillRegistry,
    private val aiBrain: AiBrainService
) {
    suspend fun processRequest(userInput: String, conversationId: String): ActionResult {
        if (userInput.isBlank()) {
            return ActionResult.Failure("I didn't catch that. How can I help?")
        }

        val resolution = classifier.classify(userInput)

        if (resolution.requiresConfirmation) {
            return ActionResult.RequiresConfirmation(
                prompt = resolution.confirmationPrompt ?: "Are you sure you want to proceed?",
                onConfirmPayload = resolution.payload
            )
        }

        return when (resolution.route) {
            ExecutionRoute.DIRECT_ANDROID_ACTION -> {
                val skill = skillRegistry.findSkill(resolution.payload)
                skill?.execute(resolution.payload)
                    ?: ActionResult.Failure("I understand what you want, but I don't have that skill installed yet.")
            }

            ExecutionRoute.AI_CONVERSATION -> {
                try {
                    val response = aiBrain.askAssistant(userInput, conversationId)
                    ActionResult.Success(spokenFeedback = response, displayFeedback = response)
                } catch (e: Exception) {
                    ActionResult.Failure("I'm having trouble reaching my brain right now. Please try again in a moment.")
                }
            }

            ExecutionRoute.UNSUPPORTED -> {
                ActionResult.Failure("Android platform rules or device settings prevent me from doing that.")
            }

            else -> {
                ActionResult.Failure("Handling for ${resolution.route} is currently in development.")
            }
        }
    }
}

// domain/voice/VoiceOutputService.kt
package com.coco.assistant.domain.voice

interface VoiceOutputService {
    fun speak(text: String, onComplete: () -> Unit = {})
    fun stop()
    fun isSpeaking(): Boolean
}
// data/voice/AndroidTtsServiceImpl.kt
package com.coco.assistant.data.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.coco.assistant.domain.voice.VoiceOutputService
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.Locale
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AndroidTtsServiceImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : VoiceOutputService, TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isInitialized = false

    init {
        tts = TextToSpeech(context, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.getDefault()
            isInitialized = true
        }
    }

    override fun speak(text: String, onComplete: () -> Unit) {
        if (!isInitialized) return

        val utteranceId = UUID.randomUUID().toString()
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) {
                if (id == utteranceId) onComplete()
            }
            override fun onError(id: String?) {}
        })

        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    override fun stop() {
        tts?.stop()
    }

    override fun isSpeaking(): Boolean = tts?.isSpeaking == true
}
// ui/components/CocoOrb.kt
package com.coco.assistant.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.coco.assistant.domain.model.VoiceState

@Composable
fun CocoOrb(
    voiceState: VoiceState,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "OrbPulse")

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (voiceState is VoiceState.Listening) 800 else 2400,
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "OrbScale"
    )

    val orbColors = when (voiceState) {
        is VoiceState.Listening -> listOf(Color(0xFF00E5FF), Color(0xFF1DE9B6))
        is VoiceState.Thinking, is VoiceState.Understanding -> listOf(Color(0xFF7C4DFF), Color(0xFF651FFF))
        is VoiceState.Speaking -> listOf(Color(0xFFFF4081), Color(0xFFFF9100))
        is VoiceState.Error -> listOf(Color(0xFFFF1744), Color(0xFFD50000))
        else -> listOf(Color(0xFF2979FF), Color(0xFF00B0FF)) // Idle
    }

    Canvas(modifier = modifier.size(240.dp)) {
        val radius = (size.minDimension / 2.2f) * if (voiceState is VoiceState.Listening) pulseScale else 1f

        drawCircle(
            brush = Brush.radialGradient(
                colors = orbColors.map { it.copy(alpha = 0.35f) } + listOf(Color.Transparent),
                radius = radius * 1.35f
            ),
            radius = radius * 1.35f
        )

        drawCircle(
            brush = Brush.radialGradient(
                colors = orbColors,
                radius = radius
            ),
            radius = radius
        )
    }
}
// data/skills/AppLauncherSkill.kt
package com.coco.assistant.data.skills

import android.content.Context
import android.content.Intent
import com.coco.assistant.domain.model.ActionResult
import com.coco.assistant.domain.model.IntentPayload
import com.coco.assistant.domain.skills.CocoSkill
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

class AppLauncherSkill @Inject constructor(
    @ApplicationContext private val context: Context
) : CocoSkill {

    override val id: String = "skill_app_launcher"
    override val displayName: String = "App Launcher"

    override fun canHandle(payload: IntentPayload): Boolean {
        return payload.actionType == "OPEN_APP" && payload.parameters.containsKey("package_name")
    }

    override suspend fun execute(payload: IntentPayload): ActionResult {
        val packageName = payload.parameters["package_name"] as? String
            ?: return ActionResult.Failure("App package identifier is missing.")

        val appName = payload.parameters["app_name"] as? String ?: "the application"

        val launchIntent: Intent? = context.packageManager.getLaunchIntentForPackage(packageName)

        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            ActionResult.Success(spokenFeedback = "Opening $appName.")
        } else {
            ActionResult.Failure(
                spokenFeedback = "I couldn't find $appName installed on your phone.",
                technicalReason = "Package $packageName not found or launch intent unavailable."
            )
        }
    }
}
